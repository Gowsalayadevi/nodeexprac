const express= require('express');
const app= express();
const bodyparser= require('body-parser');
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());
const cors= require('cors');
app.use(cors());

const port = 8000;
const server= app.listen(port,listening);
function listening(){
  console.log("server RUnning");
  console.log('running on localhost: ${port}');
}
const data=[];
app.post('/addmovie',addmovie);
function addmovie(req,res){
  data.push(req.body);
  console.log(data);
}